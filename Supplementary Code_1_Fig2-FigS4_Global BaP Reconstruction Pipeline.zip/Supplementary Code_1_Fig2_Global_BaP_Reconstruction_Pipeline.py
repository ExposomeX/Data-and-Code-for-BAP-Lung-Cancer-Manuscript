"""
================================================================================
Title: Global Spatiotemporal Reconstruction & Visualization of BaP (1850-2100)
Part: Full Integrated Pipeline for Main Text Figure 2
--------------------------------------------------------------------------------
This script reproduces Figure 2 of the manuscript. 
Scientific Core: 900-tile localized TabPFN modeling & Spatial pattern restoration.

Description:
    1. Module 1: Generates 0.1° spatial weight mask from reference climatology.
    2. Module 2: Localized TabPFN modeling engine for regional sensitivity.
    3. Module 3: Distributed orchestrator for multi-GPU parallelization.
    4. Module 4: Spatial disaggregation (1.0° to 0.1°) and yearly aggregation.
    5. Module 5: Publication-quality visualization (Fig 2 maps).

Author: Han Zhang (Peking University)
Date: 2026-03-09
================================================================================
"""

import os
import argparse
import numpy as np
import pandas as pd
import xarray as xr
import pickle
import torch
import warnings
import time
import subprocess
import multiprocessing as mp
from pathlib import Path
from tqdm import tqdm
from tabpfn import TabPFNRegressor
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.colors import LogNorm

warnings.filterwarnings("ignore")

# ==============================================================================
# 1. GLOBAL CONFIGURATION (Academic & Engineering Setup)
# ==============================================================================
class Config:
    """Centralized configuration for paths and scientific parameters."""
    # Path management (De-identified for GitHub standard)
    BASE_DIR = Path("./")
    DATA_RAW = BASE_DIR / "data/raw"             # Input dir (Reference & Forcing)
    DATA_PROC = BASE_DIR / "data/processed"     # Intermediate dir (Masks & Chunks)
    MODEL_PATH = BASE_DIR / "models/tabpfn-v2-regressor.ckpt"
    STATS_PATH = BASE_DIR / "config/global_stats_ref_1998_2007.pkl"
    SAVE_DIR = BASE_DIR / "results/Figure2"
    
    # Global Grid Parameters (Spatial Tiling Strategy)
    LAT_STEP, LON_STEP = 6, 12       # 900 tiles (180/6 * 360/12)
    H_COARSE, W_COARSE = 180, 360    # 1.0-degree resolution
    H_FINE, W_FINE = 1800, 3600      # 0.1-degree resolution
    
    # Temporal Range for BaP Reconstruction
    START_YEAR, END_YEAR = 1850, 2100
    HIST_END = 2015                  # CMIP6 historical/future junction
    
    # Computing Resources (High-Performance Computing)
    N_CPUS = 6                       # CPU cores for data loading
    MAX_GPU_CONCURRENCY = 3          # Max processes sharing one GPU
    GPUS = [0, 1]                    # Available GPU IDs

# ==============================================================================
# 2. MODULE 1: SPATIAL WEIGHT MASK GENERATOR (Downscaling Foundation)
# ==============================================================================
def generate_spatial_weight_mask(cfg):
    """
    Function: Generates the 0.1-deg spatial weight mask.
    Methodology: Based on the ratio of local pixel to regional mean (1998-2007 climatology).
    Scientific Value: Restores sub-grid variability lost in coarse climate models.
    """
    print("🚀 [Module 1] Initializing Spatial Weight Mask Generation...")
    # Reference high-res data path (Replace with actual data path)
    gt_path = cfg.DATA_RAW / "reference/bapc_1998_2007_01deg.nc"
    
    if not gt_path.exists():
        print(f"⚠️ Reference file not found: {gt_path}. Skipping mask generation."); return

    ds = xr.open_dataset(gt_path)
    # Step A: Climatological mean (1998-2007) to capture stable spatial hotspots
    bap_mean_01 = ds['bapc_concentration'].mean(dim='time').values
    
    # Step B: Downsample to 1.0-deg regional background
    vals_filled = np.nan_to_num(bap_mean_01)
    # Reshape (1800, 3600) -> (180, 10, 360, 10) then aggregate 10x10 blocks
    mean_1deg = vals_filled.reshape(180, 10, 360, 10).mean(axis=(1, 3))
    
    # Step C: Upsample (Broadcast) back to 0.1-deg
    mean_expanded = np.repeat(np.repeat(mean_1deg, 10, axis=0), 10, axis=1)
    
    # Step D: Final Ratio Calculation (Spatial Index)
    # Weight = Pixel_Conc / Regional_Mean
    weights = bap_mean_01 / (mean_expanded + 1e-10)
    weights = np.where(np.isnan(bap_mean_01), np.nan, weights) # Maintain oceanic mask
    
    mask_out = cfg.DATA_PROC / "spatial_weights_final.npy"
    mask_out.parent.mkdir(parents=True, exist_ok=True)
    np.save(mask_out, weights.astype(np.float32))
    print(f"✅ Spatial Pattern Mask saved to: {mask_out}")

# ==============================================================================
# 3. MODULE 2: REGIONALIZED INFERENCE WORKER (TabPFN Localized Modeling)
# ==============================================================================
def init_gpu_lock(sem):
    """Initializes the GPU semaphore for process pool synchronization."""
    global gpu_semaphore
    gpu_semaphore = sem

def process_single_tile(info):
    """
    Core Research Logic: Regionalized Modeling Tile by Tile.
    Input: Coordinate bounds, SSP scenario, and temporal indices.
    """
    lat_s, lat_e, lon_s, lon_e, t_start, t_end, ssp, gpu_id, cfg, stats = info
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    
    try:
        # --- A. Contextual Training Data (1998-2007 Baseline) ---
        train_X = []
        # Loading 5 Meteorological Covariates
        for var in ['tas', 'huss', 'psl', 'sfcWind', 'bldep']:
            p = cfg.DATA_RAW / f"hist/meteor/{var}_1998_2007_1.0deg.npy"
            tile = np.load(p, mmap_mode='r')[:96, lat_s:lat_e, lon_s:lon_e]
            # Normalization using reference statistics
            if var == 'bldep': val = np.log10(tile + 1e-8)
            else: val = (tile - stats[f'{var}_mean']) / (stats[f'{var}_std'] + 1e-8)
            train_X.append(val.ravel())

        # Loading Emission Inventories (Multi-sector & Multi-species)
        for sp in ['bc', 'nox', 'oc']:
            for sec in ['agr', 'ene', 'ind', 'tra', 'rco', 'slv', 'wst', 'shp']:
                p = cfg.DATA_RAW / f"hist/emiss/{sp}/{sec}_1998_2007_1.0deg.npy"
                if p.exists():
                    tile = np.load(p, mmap_mode='r')[:96, lat_s:lat_e, lon_s:lon_e]
                else:
                    tile = np.zeros((96, 6, 12))
                train_X.append(np.log10(np.clip(tile, 0, None) + 1e-8).ravel())

        X_train = np.stack(train_X, axis=1).astype(np.float32)
        y_p = cfg.DATA_RAW / "hist/target/bapc_1998_2007_1.0deg.npy"
        y_raw = np.load(y_p, mmap_mode='r')[:96, lat_s:lat_e, lon_s:lon_e]
        y_train = np.log10(np.clip(y_raw, 0, None) + 1e-8).ravel().astype(np.float32)

        # --- B. Prediction Features (Target Scenario forcing) ---
        query_X = []
        for var in ['tas', 'huss', 'psl', 'sfcWind', 'bldep']:
            p = cfg.DATA_RAW / f"future/forcing/{ssp}/{var}_1850_2100.npy"
            tile = np.load(p, mmap_mode='r')[t_start:t_end, lat_s:lat_e, lon_s:lon_e]
            query_X.append( (np.log10(tile+1e-8) if var=='bldep' else (tile-stats[f'{var}_mean'])/(stats[f'{var}_std']+1e-8)).ravel() )

        for sp in ['bc', 'nox', 'oc']:
            for sec in ['agr', 'ene', 'ind', 'tra', 'rco', 'slv', 'wst', 'shp']:
                p = cfg.DATA_RAW / f"future/emiss/{ssp}/{sp}/{sec}_1850_2100.npy"
                tile = np.load(p, mmap_mode='r')[t_start:t_end, lat_s:lat_e, lon_s:lon_e]
                query_X.append(np.log10(np.clip(tile, 0, None) + 1e-8).ravel())
        
        X_test = np.stack(query_X, axis=1).astype(np.float32)

        # --- C. TabPFN Inference (GPU-Locked Session) ---
        with gpu_semaphore:
            # TabPFN performs in-context learning based on the training block
            model = TabPFNRegressor(device='cuda', n_estimators=32, model_path=cfg.MODEL_PATH)
            model.fit(X_train, y_train)
            pred_log = model.predict(X_test)
            torch.cuda.empty_cache()
            
        return {'coords': (lat_s, lat_e, lon_s, lon_e), 'pred': pred_log.reshape(t_end-t_start, 6, 12)}

    except Exception as e:
        print(f"❌ Worker Error at Tile [{lat_s}:{lon_s}]: {e}"); return None

# ==============================================================================
# 4. MODULE 3: DISTRIBUTED ORCHESTRATION (Multi-GPU Task Dispatcher)
# ==============================================================================
def run_distributed_orchestrator(cfg):
    """
    Function: Manages 900-tile parallel modeling tasks across multi-GPUs.
    Scientific Value: Handles global 251-year high-res reconstruction efficiently.
    """
    print(f"🔥 [Module 3] Starting Distributed Orchestrator...")
    
    with open(cfg.STATS_PATH, 'rb') as f:
        stats = pickle.load(f)

    for ssp in ['ssp126', 'ssp245', 'ssp370', 'ssp585']:
        print(f"\n{'='*40}\nProcessing Scenario: {ssp.upper()}\n{'='*40}")
        
        # Historical segments (1850+) or Future projections (2015+)
        start_year = 1850 if ssp == 'ssp126' else 2015
        t_start, t_end = (start_year - 1850) * 12, (cfg.END_YEAR - 1850 + 1) * 12
        n_months = t_end - t_start

        # Dispatching 900 regional modeling tasks
        tasks = []
        for i in range(0, cfg.H_COARSE, cfg.LAT_STEP):
            for j in range(0, cfg.W_COARSE, cfg.LON_STEP):
                gpu_id = cfg.GPUS[(i // cfg.LAT_STEP + j // cfg.LON_STEP) % len(cfg.GPUS)]
                tasks.append((i, i + cfg.LAT_STEP, j, j + cfg.LON_STEP, 
                              t_start, t_end, ssp, gpu_id, cfg, stats))
        
        # Resource management
        manager = mp.Manager()
        sem = manager.Semaphore(cfg.MAX_GPU_CONCURRENCY)
        ctx = mp.get_context('spawn')
        full_pred_1deg = np.zeros((n_months, cfg.H_COARSE, cfg.W_COARSE), dtype=np.float32)
        
        with ctx.Pool(processes=cfg.N_CPUS, initializer=init_gpu_lock, initargs=(sem,)) as pool:
            for res in tqdm(pool.imap_unordered(process_single_tile, tasks), 
                            total=len(tasks), desc=f"Modeling {ssp}"):
                if res is not None:
                    ls, le, ns, ne = res['coords']
                    full_pred_1deg[:, ls:le, ns:ne] = res['pred']

        # Saving consolidated 1.0-degree monthly fields
        out_path = cfg.DATA_PROC / f"pred_{ssp}_1.0deg_monthly.npy"
        np.save(out_path, full_pred_1deg)
        print(f"✅ 1.0-degree monthly field consolidated for {ssp}")

# ==============================================================================
# 5. MODULE 4: SPATIAL DOWNSCALING & AGGREGATION (0.1-deg Integration)
# ==============================================================================
def downscale_to_fine_resolution(cfg, ssp):
    """
    Function: Converts 1.0-deg monthly data to 0.1-deg annual exposure maps.
    Methodology: Spatial upsampling + pattern restoration via weight mask.
    """
    print(f"🚀 [Module 4] Downscaling {ssp} to 0.1-degree Annual Mean...")
    mask = np.load(cfg.DATA_PROC / "spatial_weights_final.npy")
    
    in_file = cfg.DATA_PROC / f"pred_{ssp}_1.0deg_monthly.npy"
    data_1deg = np.load(in_file, mmap_mode='r').reshape(-1, 180, 360)
    
    n_years = data_1deg.shape[0] // 12
    res_01deg_yearly = np.zeros((n_years, cfg.H_FINE, cfg.W_FINE), dtype=np.float32)

    for y_idx in tqdm(range(n_years), desc=f"Downscaling {ssp}"):
        # Yearly Mean calculation
        yr_mean_1deg = np.mean(data_1deg[y_idx*12 : (y_idx+1)*12], axis=0)
        # Upsampling (10x10 block expansion)
        base_01 = np.repeat(np.repeat(yr_mean_1deg, 10, axis=0), 10, axis=1)
        # Weighting for pattern restoration
        res_01deg_yearly[y_idx] = np.nan_to_num(base_01 * mask, nan=0.0)

    final_out = cfg.SAVE_DIR / f"weighted_yearly_{ssp}.npy"
    np.save(final_out, res_01deg_yearly)
    print(f"✅ Final 0.1-deg annual dataset produced: {final_out}")

# ==============================================================================
# 6. MODULE 5: PUBLICATION VISUALIZATION (Figure 2 Graphics)
# ==============================================================================
def plot_figure_2_final(cfg, ssp='ssp245', year=2050):
    """
    Function: Generates high-fidelity global maps.
    Scientific Standard: Uses LogNorm to visualize extreme concentration gradients.
    """
    print(f"🎨 [Module 5] Generating Figure 2 Publication Map...")
    data_path = cfg.SAVE_DIR / f"weighted_yearly_{ssp}.npy"
    if not data_path.exists(): return
    
    y_idx = year - cfg.START_YEAR
    data_viz = np.load(data_path, mmap_mode='r')[y_idx]
    # Center longitude adjustment for visual balance
    data_viz = np.roll(data_viz, 1800, axis=1)

    fig = plt.figure(figsize=(12, 7))
    ax = plt.axes(projection=ccrs.PlateCarree())
    
    # LogNorm is essential for BaP (values spanning 4 orders of magnitude)
    im = ax.imshow(data_viz, origin='lower', extent=[-180, 180, -90, 90],
                   transform=ccrs.PlateCarree(), cmap='Spectral_r', 
                   norm=LogNorm(vmin=0.001, vmax=1.0), interpolation='nearest')
    
    ax.add_feature(cfeature.COASTLINE, linewidth=0.6, edgecolor='#222222')
    ax.add_feature(cfeature.BORDERS, linewidth=0.3, edgecolor='gray', alpha=0.5)
    
    plt.title(f"Global BaP Concentration ({year}, {ssp.upper()})", fontsize=16, fontweight='bold')
    cbar = plt.colorbar(im, ax=ax, orientation='vertical', shrink=0.7, pad=0.02)
    cbar.set_label('Concentration (ng/m³)', fontsize=12)
    
    plt.savefig(cfg.SAVE_DIR / f"Figure2_Map_{year}_{ssp}.png", dpi=300, bbox_inches='tight')
    plt.close()

# ==============================================================================
# MAIN PIPELINE ENTRY
# ==============================================================================
if __name__ == "__main__":
    pipeline_cfg = Config()
    
    # 1. Run Spatial Mask Generation
    # generate_spatial_weight_mask(pipeline_cfg)
    
    # 2 & 3. Run Regionalized Parallel Inference
    # for scenario in ['ssp126', 'ssp245', 'ssp370', 'ssp585']:
    #     run_distributed_orchestrator(pipeline_cfg)
    
    # 4. Downscale and Aggregate to Annual Maps
    # for scenario in ['ssp126', 'ssp245', 'ssp370', 'ssp585']:
    #     downscale_to_fine_resolution(pipeline_cfg, scenario)
        
    # 5. Output Graphics
    # plot_figure_2_final(pipeline_cfg, ssp='ssp245', year=2050)
    
    print("\n🎉 Full Figure 2 Pipeline ready. (Enable modules to execute)")