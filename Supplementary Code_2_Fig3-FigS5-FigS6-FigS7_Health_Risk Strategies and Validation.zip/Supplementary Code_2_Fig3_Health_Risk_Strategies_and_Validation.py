"""
================================================================================
Title: Global Lung Cancer Risk Assessment (PAF) across S0-S3 Strategies
Part 1: Computational Engine (Strategy Definitions & PAF Integration)
--------------------------------------------------------------------------------
This script reproduces Figure 3 and associated supplementary figures.
Four modeling strategies are implemented to quantify lung cancer risk:
1. S0_Static_Current: Baseline assuming lifelong exposure to current intensity.
2. S1_History_Cumulative: Sum of past 70-yr concentrations (no demographics).
3. S2_Dynamic_NoLatency: Dynamic cohorts with immediate risk (no biological lag).
4. S3_Dynamic_WithLatency: Full model with cohorts and Weibull lag weights.

Scientific Core: Power-law CRF (URR=4.9) and Weibull Biological Lag.
Author: Han Zhang (Peking University)
Date: 2026-03-09
================================================================================
"""

import os
import numpy as np
import pandas as pd
import xarray as xr
import pickle
import pycountry
import multiprocessing as mp
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.colors as mcolors
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from pathlib import Path
from tqdm import tqdm
from matplotlib.colors import LogNorm
import warnings
import gc
import math

warnings.filterwarnings('ignore')

# ==============================================================================
# 1. GLOBAL CONFIGURATION
# ==============================================================================
class Config:
    # Path settings (Portable for GitHub)
    BASE_DIR = Path("./")
    DATA_ROOT = BASE_DIR / "data/risk_assessment"
    # Inputs
    MASK_INDEX = DATA_ROOT / "mask/global_country_mask_01deg_index.npy"
    MAPPING_CSV = DATA_ROOT / "mask/pixel_to_un_mapping.csv"
    AGE_DICT = DATA_ROOT / "demographics/age_prop_1950_2100_dict.pkl"
    CONC_DIR = DATA_ROOT / "exposure/weighted_01deg_yearly"
    POP_DIR = DATA_ROOT / "population/aligned_01deg"
    WEIGHTS_CSV = DATA_ROOT / "weights/weibull_lag_weights_k2.csv"
    # Outputs
    SAVE_DIR_DATA = BASE_DIR / "results/Figure3/data"
    SAVE_DIR_FIGS = BASE_DIR / "results/Figure3/figures"
    
    # Model Parameters
    URR_VAL = 4.9
    BENCHMARK = 100000.0  # ng/m3 * year (Reference: Chen et al. 2009)
    YEARS = np.arange(1950, 2101)
    SSP_LIST = ['126', '245', '370', '585']
    
    # Visualization
    STRATEGY_COLORS = {
        'S3_Dynamic_WithLatency': '#D62728', 'S2_Dynamic_NoLatency': '#1F77B4', 
        'S1_History_Cumulative': '#2CA02C', 'S0_Static_Current': '#FF7F0E'
    }
    COUNTRY_ORDER = ['CHN', 'USA', 'GBR', 'IND', 'BRA', 'ZAF']
    COUNTRY_NAMES = {'CHN': 'China', 'USA': 'USA', 'GBR': 'UK', 'IND': 'India', 'BRA': 'Brazil', 'ZAF': 'South Africa'}

# ==============================================================================
# 2. CORE RISK FUNCTIONS
# ==============================================================================
def calc_paf_power_law(exposure_array, cfg):
    """Calculates PAF based on the non-linear Power-law RR model."""
    # rr = URR ^ (Cumulative_Exposure / Benchmark)
    rr = np.power(cfg.URR_VAL, np.maximum(exposure_array, 0) / cfg.BENCHMARK)
    return np.clip(1.0 - (1.0 / rr), 0.0, 1.0)

def init_risk_worker(cfg):
    """Initializes shared resources for parallel PAF calculation."""
    global SHARED_RES
    mask_idx = np.load(cfg.MASK_INDEX)
    map_df = pd.read_csv(cfg.MAPPING_CSV)
    
    max_idx = map_df['Mask_Index'].max()
    idx_to_un = np.full(max_idx + 1, -1, dtype=np.int32)
    for _, row in map_df.iterrows():
        idx_to_un[int(row['Mask_Index'])] = int(row['Calculation_UN_Code'])
    
    mask_un_grid = idx_to_un[mask_idx]
    valid_mask = mask_un_grid >= 0
    
    with open(cfg.AGE_DICT, 'rb') as f:
        age_prop_dict = pickle.load(f)
        
    lag_weights = pd.read_csv(cfg.WEIGHTS_CSV)['Weight'].values
    
    SHARED_RES = {
        'valid_mask': valid_mask,
        'flat_codes': mask_un_grid[valid_mask],
        'age_prop_dict': age_prop_dict,
        'mask_un_grid': mask_un_grid,
        'lag_weights': lag_weights,
        'code_map': map_df.set_index('Calculation_UN_Code')['Country_Name'].to_dict()
    }

# ==============================================================================
# 3. MODULE 2: PAF CALCULATION ENGINE (Updated S0-S3 Logic)
# ==============================================================================
def process_paf_year(args):
    ssp, year, cfg = args
    res = SHARED_RES
    y_idx = year - 1850
    
    # Load 0.1-degree spatial layers
    conc_full = np.load(cfg.CONC_DIR / f"weighted_yearly_ssp{ssp}.npy", mmap_mode='r')
    pop_full = np.load(cfg.POP_DIR / f"pop_final_ssp{ssp}.npy", mmap_mode='r')
    
    pop_flat = pop_full[y_idx][res['valid_mask']]
    valid_codes_grid = res['mask_un_grid'][res['valid_mask']]
    
    # --- S0: Static Current Exposure (lifelong current intensity) ---
    # Assumption: Exposed to current concentration for full 70 years
    conc_now = conc_full[y_idx][res['valid_mask']]
    paf_grid_s0 = calc_paf_power_law(conc_now * 70.0, cfg)
    
    # --- S1: Simple Historical Cumulative (No demographics) ---
    # Assumption: Simple sum of past 70 years of concentration
    start_hist = max(0, y_idx - 69)
    ce_s1 = np.sum(conc_full[start_hist : y_idx + 1], axis=0)[res['valid_mask']]
    paf_grid_s1 = calc_paf_power_law(ce_s1, cfg)
    
    # --- S2 & S3: Dynamic Cohort Analysis (Historical Back-look) ---
    age_props = res['age_prop_dict'].get(year, {})
    max_un = int(np.max(res['mask_un_grid'])) + 1
    lookup_age = np.zeros((max_un, 101), dtype=np.float32)
    for code, props in age_props.items():
        if code < max_un: lookup_age[code] = props

    lookback = min(100, y_idx + 1)
    hist_valid = conc_full[y_idx - lookback + 1 : y_idx + 1][::-1][:, res['valid_mask']]
    
    # S2: Cumulative Exposure (Immediate Risk, No Lag)
    ce_stack_s2 = np.cumsum(hist_valid, axis=0)
    # S3: Weighted Effective Exposure (Biological Latency Lag)
    ce_stack_s3 = np.cumsum(hist_valid * res['lag_weights'][:lookback, np.newaxis], axis=0)
    
    paf_integrated_s2 = np.zeros_like(pop_flat)
    paf_integrated_s3 = np.zeros_like(pop_flat)
    
    # Integrate risks across the 100-year age structure
    for a in range(1, 101):
        if a > lookback: break
        p_age_s2 = calc_paf_power_law(ce_stack_s2[a-1], cfg)
        p_age_s3 = calc_paf_power_law(ce_stack_s3[a-1], cfg)
        # Weigh by population proportion for year t
        prop = lookup_age[valid_codes_grid, a]
        paf_integrated_s2 += (p_age_s2 * prop)
        paf_integrated_s3 += (p_age_s3 * prop)
        
    # National Aggregation
    records = []
    unique_c = np.unique(res['flat_codes'])
    for code in unique_c:
        mask_c = (res['flat_codes'] == code)
        pop_c = np.sum(pop_flat[mask_c])
        if pop_c > 0:
            for s_name, g_data in zip(['S0_Static_Current', 'S1_History_Cumulative', 
                                       'S2_Dynamic_NoLatency', 'S3_Dynamic_WithLatency'], 
                                      [paf_grid_s0, paf_grid_s1, paf_integrated_s2, paf_integrated_s3]):
                paf_val = np.sum(g_data[mask_c] * pop_flat[mask_c]) / pop_c
                records.append((year, f'SSP{ssp}', s_name, code, pop_c, paf_val))
    return records