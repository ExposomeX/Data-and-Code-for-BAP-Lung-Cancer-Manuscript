"""
================================================================================
Title: Global Lung Cancer Burden Downscaling & Visualization (Figure 4)
Part: Spatial Downscaling of GBD Statistics to 0.1-degree Grid
--------------------------------------------------------------------------------
Methodology:
    1. Weight Calculation: Weight(g) = Population(g) * PAF(g)
    2. Spatial Allocation: 
       Death(g) = Total_National_Deaths * [Weight(g) / Sum_of_Weights_National]
    3. Aggregation: 1990-2023 Historical Climatological Mean.

Scientific Standard: Integrated with Cartopy for Publication-ready Graphics.
Author: Han Zhang (Peking University)
Date: 2026-03-09
================================================================================
"""

import os
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.colors as mcolors
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from pathlib import Path
from tqdm import tqdm
import warnings

warnings.filterwarnings('ignore')

# ==================== 1. CONFIGURATION (De-identified) ====================
class Config:
    # Path Settings
    BASE_DIR = Path("./")
    GBD_FILE = BASE_DIR / "data/IHME-GBD_2023_LungCancer_Deaths.csv"
    MASK_INDEX = BASE_DIR / "data/mask/global_country_mask_01deg_index.npy"
    MAPPING_CSV = BASE_DIR / "data/mask/pixel_to_country_mapping.csv"
    
    # Pre-computed Exposure & Population (from Fig 2 & 3)
    POP_FILE = BASE_DIR / "data/pop_ssp245.npy"
    PAF_FILE = BASE_DIR / "results/paf_ssp245.npy"
    
    SAVE_DIR = BASE_DIR / "results/Figure4"
    
    # Analysis Period
    START_YEAR, END_YEAR = 1990, 2023
    
    # Visualization
    CMAP = 'YlOrRd'
    V_MIN, V_MAX = 0.001, 100.0  # Log-scale range for deaths per pixel

# ==================== 2. MODULE: SPATIAL DOWNSCALING ====================

def run_spatial_downscaling(cfg):
    """
    Core Logic: Distributes national GBD deaths to grid cells based on 
    local population density and risk (PAF).
    """
    print("🚀 Starting Spatial Downscaling of Health Burden...")
    
    # 1. Load Metadata
    mask_idx = np.load(cfg.MASK_INDEX)
    map_df = pd.read_csv(cfg.MAPPING_CSV)
    
    # Map Pixel Index to UN Country Code
    idx_to_id = np.full(map_df['Mask_Index'].max() + 1, -1, dtype=np.int32)
    for _, row in map_df.iterrows():
        idx_to_id[int(row['Mask_Index'])] = int(row['Calculation_UN_Code'])
    
    mask_id_grid = idx_to_id[mask_idx]
    valid_mask = mask_id_grid >= 0
    pixel_country_ids = mask_id_grid[valid_mask]
    
    # 2. Load GBD Statistics
    gbd_df = pd.read_csv(cfg.GBD_FILE)
    
    # 3. Process Year-by-Year to get Climatological Mean
    pop_data = np.load(cfg.POP_FILE, mmap_mode='r')
    paf_data = np.load(cfg.PAF_FILE, mmap_mode='r')
    
    accumulated_deaths = np.zeros(mask_idx.shape, dtype=np.float32)
    count = 0

    for year in tqdm(range(cfg.START_YEAR, cfg.END_YEAR + 1), desc="Allocating Deaths"):
        y_idx_pop = year - 1850
        y_idx_paf = year - 1950
        
        # Calculate Local Weight = Population * PAF
        w = np.maximum(pop_data[y_idx_pop][valid_mask] * paf_data[y_idx_paf][valid_mask], 0)
        
        # Compute National Sum of Weights
        country_total_weights = np.bincount(pixel_country_ids, weights=w)
        
        # Map National GBD Deaths to Grid
        gbd_yr = gbd_df[gbd_df['Year'] == year]
        target_lookup = np.zeros(len(country_total_weights))
        target_lookup[gbd_yr['UN_Code'].values.astype(int)] = gbd_yr['Attributable_Deaths'].values
        
        # Weighted Allocation
        denom = country_total_weights[pixel_country_ids]
        factor = np.where(denom > 0, w / denom, 0)
        
        # Restore to 2D
        grid_flat = factor * target_lookup[pixel_country_ids]
        grid_2d = np.zeros(mask_idx.shape, dtype=np.float32)
        grid_2d[valid_mask] = grid_flat
        
        accumulated_deaths += grid_2d
        count += 1

    mean_deaths = accumulated_deaths / count
    return mean_deaths

# ==================== 3. MODULE: PUBLICATION MAPPING ====================

def plot_death_map(data, cfg):
    """
    Scientific Visualization: Global map of attributable lung cancer deaths.
    Uses LogNorm to capture spatial heterogeneity (Urban vs Rural).
    """
    print("🎨 Generating Figure 4E Publication Map...")
    
    # Data preprocessing for visualization (Central longitude 0)
    data_viz = np.roll(data, 1800, axis=1)
    data_viz[0:300, :] = np.nan # Antarctic masking
    
    fig = plt.figure(figsize=(14, 8))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
    
    # Plotting with LogScale
    norm = mcolors.LogNorm(vmin=cfg.V_MIN, vmax=cfg.V_MAX)
    cmap = plt.get_cmap(cfg.CMAP).copy()
    cmap.set_under('white')
    
    im = ax.imshow(data_viz, origin='lower', extent=[-180, 180, -90, 90],
                   transform=ccrs.PlateCarree(), cmap=cmap, norm=norm)
    
    ax.add_feature(cfeature.COASTLINE, linewidth=0.4, color='#333333')
    ax.add_feature(cfeature.BORDERS, linewidth=0.2, edgecolor='#555555', alpha=0.5)
    
    # Styling
    plt.title(f"Historical Mean Attributable Lung Cancer Deaths ({cfg.START_YEAR}-{cfg.END_YEAR})", 
              fontsize=16, fontweight='bold')
    
    cbar = plt.colorbar(im, ax=ax, orientation='vertical', shrink=0.6, extend='both')
    cbar.set_label('Deaths per 0.1° Grid Cell', fontweight='bold')
    
    # Save both versions
    cfg.SAVE_DIR.mkdir(parents=True, exist_ok=True)
    plt.savefig(cfg.SAVE_DIR / "Fig4E_Deaths_Map_Full.png", dpi=300, bbox_inches='tight')
    
    # Bare version for layout
    ax.set_title(""); cbar.remove()
    plt.savefig(cfg.SAVE_DIR / "Fig4E_Deaths_Map_Bare.png", dpi=300, bbox_inches='tight', pad_inches=0)
    plt.close()

# ==================== 4. MAIN ENTRY ====================
if __name__ == "__main__":
    pipeline_cfg = Config()
    
    # 1. Calculation
    mean_deaths_grid = run_spatial_downscaling(pipeline_cfg)
    
    # 2. Visualization
    plot_death_map(mean_deaths_grid, pipeline_cfg)
    
    print("🎉 Figure 4 Spatial Downscaling Pipeline Finished.")